from sys import argv
from pyshgp.gp.genome import Genome, GenomeArchive
from pyshgp.gp.individual import Individual
from psb import program_synth as ps


problem, search, npop, ngen, nproc, seed = argv[1:]
csl = Individual.load("compare-string-lengths/1004.sol").genome
md = Individual.load("median/1010.sol").genome
garch = GenomeArchive([
    csl[:3], csl[3:5], csl[5:7], csl[7:10], csl[10:],
    md[:2], md[2:3], md[5:6], md[6:9], md[9:]
])


if __name__ == "__main__":

    est = ps(problem=problem,
             search=search,
             npop=int(npop),
             ngen=int(ngen),
             nproc=int(nproc),
             seed=int(seed),
             archive=garch,
             replacement_rate=0.1,
             adaptation_rate=0.5,
             savepop=f"{problem}/{seed}.hst")

    est.save(f"{problem}/{seed}.sol")
